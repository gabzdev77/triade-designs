document.getElementById('form-discord').addEventListener('submit', function (e) {
  e.preventDefault();
  document.getElementById('resposta').textContent = "Pedido enviado com sucesso (simulado).";
});
